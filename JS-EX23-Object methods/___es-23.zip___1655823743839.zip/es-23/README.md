# Object Methods - Exercise 1

Utilizzando l'oggetto `person`, stampare in console le coppie chiave/valore, provando ad utilizzare il metodo `Object.keys`:

```
firstName: Mario
lastName: Rossi
age: 25
```
